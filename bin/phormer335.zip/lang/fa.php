<?php
/*
  * Translation System for Phormer (http://p.horm.org/er)
  * Language: Farsi
  * Author: Aideen NasiriShargh <aideen[at]gmail[dot]om>
  *
  * Translation 1.0: May 03, 2008
  */
  	$_['manage photos']				= 'مدیریت عکس‌ها';
	$_['of']						= 'ی';
	
	$_['change password'] 			= 'تغییر گذرواژه';
	$_['uninstall phormer']			= 'حذف کامل Phormer';
	
	$_['configurations']			= 'پیکربندی‌ها';
	
	$_['modular actions'] 			= 'عملیات جانبی';
	$_['external modular actions']	= 'عملیات جانبی خارجی';
	$_['advanced options']			= 'اعمال پیش‌رفته';
	$_['default num of photos in box mode'] 			= 'تعداد پیش‌فرض عکس‌ها در سبک «جعبه»';
	$_['default num of photos in recent photos'] 		= 'تعداد پیش‌فرض عکس‌ها در «عکس‌های اخیر»';
	$_['default num of photos in top rated/visited'] 	= 'تعداد پیش‌فرض عکس‌ها در «محبوب‌/پربازدید ترین»';
	$_['default num of stories in story mode'] 			= 'تعداد پیش‌فرض داستان‌ها در سبک «داستان‌ها»';
	$_['default num of stories in side bar'] 			= 'تعداد پیش‌فرض داستان‌ها در منوی کناری';
//$_['']				= '';
?>
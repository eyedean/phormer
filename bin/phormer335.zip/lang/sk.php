<?php
/*
  * Translation System for Phormer (http://p.horm.org/er)
  * Language: Slovak
  * Author: Aideen NasiriShargh <aideen[at]gmail[dot]om>
  *
  * Translation 1.0: May 03, 2008
  */
?>